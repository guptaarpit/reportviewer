/* eslint-disable react/prop-types */
/**
 * Created by arpit on 7/5/2017.
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import numeral from 'numeral';
import { fetchCUList, renderDashboard } from '../../actions/dashboard';
import { SELECTED_CU, FIRSTQTR, SECONDQTR, LIST } from '../../actions/types';

class Loan extends Component {

  

  render() {
    // this.props.renderReport(this.props.selectedCU);
    return (
      <div>
        <table style={{ width: '100%', 'text-align': 'center' }} className="well nav nav-stacked table table-inverse text-center">
          <thead>
          <tr className="w3-cyan text-center">
            <th className=" text-center">Metric</th>
            <th data-toggle="modal" data-target="#modal" className="text-center PeriodN">
              {keyParams[0] ? keyParams[0].Quarter : 'Latest Quarter'}
            </th>
            <th data-toggle="modal" data-target="#modal" className="text-center PeriodO">
              {keyParams[0] ? keyParams[keyParams.length - 1].Quarter : 'Starting Quarter'}
            </th>
            <th className="PeriodC text-center">Change</th>
            <th className="text-center">Trend</th>
            <th className="text-red text-center">Delete</th>
          </tr>
          </thead>
          <tbody id="ASSETS">
          {renderTableRow(metrics, keyParams, prepareData)}
          </tbody>
        </table>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedCU: state.cu.selectedCU,
    scorecardmetrics: state.cu.scorecardmetrics,
    assets: state.cu.assets,
    liabilities: state.cu.liabilities,
    keyparams: state.cu.keyparams,
    camels: state.cu.camels,
    assetbandstatepercentile: state.cu.assetbandstatepercentile,
    pearls: state.cu.pearls,
    incomeexpenses: state.cu.incomeexpenses,
    metrics: state.cu.metrics,
    firstQtr: state.cu.firstQtr,
    secondQtr: state.cu.secondQtr,
    firstQtrList: state.cu.firstQtrList,
    secondQtrList: state.cu.secondQtrList,
  };
}

const mapDispatchToProps = dispatch => ({
  selectedItem: chosenRequest => dispatch({
    type: SELECTED_CU,
    payload: chosenRequest,
  }),
  selectFirstQtr: value => dispatch({
    type: FIRSTQTR,
    payload: value,
  }),
  selectSecondQtr: value => dispatch({
    type: SECONDQTR,
    payload: value,
  }),
  renderFirstQtrList: list => dispatch({
    type: `${FIRSTQTR}${LIST}`,
    payload: list,
  }),
  renderSecondQtrList: list => dispatch({
    type: `${SECONDQTR}${LIST}`,
    payload: list,
  }),
  renderReport: (selectedCU) => {
    dispatch(renderDashboard(selectedCU.cuNumber));
  },
  fetchCUList: () => dispatch(fetchCUList()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Loan);

