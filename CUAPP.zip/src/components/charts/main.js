/* eslint-disable react/prop-types */
/**
 * Created by arpit on 7/5/2017.
 */

import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router';
import numeral from 'numeral';
import { MenuItem } from 'material-ui';
import { fetchCUList, renderDashboard } from '../../actions/dashboard';
import { SELECTED_CU, FIRSTQTR, SECONDQTR, LIST } from '../../actions/types';
import Widgets from './widget';

class Main extends PureComponent {
  componentDidMount() {
  }

  prepareData(metricItem) {
    const chartData = this.props.assets.map(item => item[metricItem.Metric]);
    return {
      barData: {
        data: {
          labels: this.props.assets.map(item => item.Quarter),
          datasets: [
            {
              label: metricItem.Caption,
              backgroundColor: 'rgba(255,99,132,0.2)',
              borderColor: 'rgba(255,99,132,1)',
              borderWidth: 1,
              hoverBackgroundColor: 'rgba(255,99,132,0.4)',
              hoverBorderColor: 'rgba(255,99,132,1)',
              data: chartData,
            },
          ],
        },
        options: {
          scales: {
            yAxes: [
              {
                display: true,
                type: 'linear',
                ticks:
                {
                  beginAtZero: true,
                  callback(value) {
                    return numeral(value).format(metricItem.format);
                  },
                },
              }],
          },

        },
      },
      itemData: this.props.assets,
      metrics: metricItem,
    };
  }

  renderFirstQtrMenu(e, props) {
    let qtrList = props.assets
        .map(item => (<MenuItem value={item.Quarter} primaryText={item.Quarter} />));
    if (props.secondQtr) {
      qtrList = props.assets.filter(item => item.Quarter !== this.props.secondQtr)
          .map(item => <MenuItem value={item.Quarter} primaryText={item.Quarter} />);
    }

    props.renderFirstQtrList(qtrList);
  }

  renderSecondQtrMenu(e, props) {
    let qtrList = props.assets
        .map(item => (<MenuItem value={item.Quarter} primaryText={item.Quarter} />));
    if (props.firstQtr) {
      qtrList = props.assets.filter(item => item.Quarter !== this.props.firstQtr)
          .map(item => <MenuItem value={item.Quarter} primaryText={item.Quarter} />);
    }

    props.renderSecondQtrList(qtrList);
  }

  renderCharts() {
    // this.renderFirstQtrMenu(e, this.props);
    const chartData = this.props.metrics.map((item) => {
      const propertyCheck = Object.prototype.hasOwnProperty.call(this.props.assets[0], item.Metric);
      if (propertyCheck && item.Drawable === 'TRUE') {
        const widgetData = this.prepareData(item);
        return (<Widgets
          barData={widgetData.barData}
          itemData={widgetData.itemData}
          metrics={widgetData.metrics}
          parentProps={this.props}
          /* renderFirstQtrMenu={e => this.renderFirstQtrMenu(e, this.props)}
          renderSecondQtrMenu={e => this.renderSecondQtrMenu(e, this.props)}*/
        />);
      }

      return '';
    });

    return chartData;
  }

  render() {
    this.props.renderReport(this.props.selectedCU);
    return (
      <div>
        <div style={{ display: 'block' }} className="box-body well">
          <div className="w3-row">
            <p className="lead w3-card-8 w3-center w3-cyan">Scorecard Metrics</p>
          </div>
          <div className="w3-row w3-row-padding">
            {this.renderCharts() }
          </div>
        </div>
        <div className="col-sm-12 text-center">
          <div className="col-sm-12 text-info">
            <h4 className="lead">Browse Score - cards</h4>
            <hr />
          </div>
        </div>
        <div className="col-sm-12">
          <h3 className="text-info w3-center">
            <u className="Heading">{this.props.selectedCU.name}</u>
          </h3>
          <p />
          <div className="nav-tabs-custom w3-card-8 bg-gray">
            <ul className="nav nav-tabs">
              <li className="active">
                <Link to="#tabs-1" data-toggle="tab" className="h4">
                  Business Analytics
                </Link>
              </li>
              <li>
                <Link to="#tabs-2" data-toggle="tab" className="h4">
                  IT Processes & Infrastructure
                </Link>
              </li>
            </ul>
            <div className="tab-content">
              <div id="tabs-1" className="tab-pane active">
                <div className="nav-tabs-custom bg-gray">
                  <ul className="nav nav-tabs">
                    <li className="">
                      <Link to="#sc1" id="tabDa1" data-toggle="tab" aria-expanded="false">
                        Overall
                      </Link>
                    </li>
                    <li className="active">
                      <Link to="#sc2" id="tabDa2" data-toggle="tab" aria-expanded="true">
                        Assets
                      </Link>
                    </li>
                    <li>
                      <Link to="#sc3" id="tabDa3" data-toggle="tab">
                        Liabilities
                      </Link>
                    </li>
                    <li>
                      <Link to="#sc4" id="tabDa4" data-toggle="tab">
                        Income & Expense
                      </Link>
                    </li>
                    <li>
                      <Link to="#sc5" id="tabDa5" data-toggle="tab">
                        PEARLS*
                      </Link>
                    </li>
                    <li>
                      <Link to="#sc6" id="tabDa6" data-toggle="tab">
                        CAMELS*
                      </Link>
                    </li>
                  </ul>
                  <div className="tab-content bg-gray">
                    <div id="sc1" className="tab-pane">
                      <button style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }} className="btn-success btn-xs pull-right">
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-aqua">
                          <p style={{ 'font-size': '25px', margin: 0 }} className="lead"> DA KeyParam Scorecard</p>
                        </div>
                        <div className="panel-body">
                          <div className="w3-row w3-center">
                            <div className="w3-col w3-half MainSC">
                              <p className="lead">Name of CU :
                                <span className="text-info lead">{this.props.selectedCU.name}</span>
                              </p>
                              <p className="lead">State :
                                <span className="text-info lead">CALIFORNIA</span>
                              </p>
                              <p className="lead">Members :
                                <span className="text-info lead">XXXX</span>
                              </p>
                            </div>
                            <div className="w3-col w3-half">
                              <p className="lead">Assets :
                                <span className="text-info lead">$ XXX B</span>
                              </p>
                              <p className="lead">Asset Band :
                                <span className="text-info lead">$ XX - XX B</span>
                              </p>
                              <p className="lead">Loans :
                                <span className="text-info lead">$ XXX B</span>
                              </p>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Key Metrics</h3>
                              <div className="box-tools pull-right">
                                <button type="button" data-widget="collapse" className="btn btn-box-tool">
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <div className="w3-row">
                                <p className="lead w3-card-8 w3-center w3-cyan">Scorecard Metrics</p>
                              </div>
                              <div className="w3-row w3-row-padding">
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4 className="w3-card-8 w3-white">Assets Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <div style={{ display: 'inline',
                                      width: '90px',
                                      height: '90px' }}
                                    >
                                      <canvas width="90" height="90" />
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.2"
                                        data-width="90"
                                        data-height="90"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                        style={{ width: '49px',
                                          height: '30px',
                                          position: 'absolute',
                                          'vertical-align': 'middle',
                                          'margin-top': '30px',
                                          'margin-left': '-69px',
                                          border: '0px',
                                          background: 'none',
                                          'font-style': 'normal',
                                          'font-variant': 'normal',
                                          'font-weight': 'bold',
                                          'font-stretch': 'normal',
                                          'font-size': '18px',
                                          'line-height': 'normal',
                                          'font-family': 'Arial',
                                          'text-align': 'center',
                                          color: 'rgb(60, 141, 188)',
                                          padding: '0px',
                                          '-webkit-appearance': 'none' }}
                                      />
                                    </div>
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4 className="w3-card-8 w3-white">Loans Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4 className="w3-card-8 w3-white">
                                      Loans per member Growth
                                    </h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4 className="w3-card-8 w3-white">Net Loans by Total loans </h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>.
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4 className="w3-card-8 w3-white" >
                                      Return on Assets
                                    </h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">ScoreCard & Ranking</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well w3-row-padding">
                              <div className="w3-row stateSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
                                          State wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
                                              Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div data-toggle="tooltip" data-placement="top" title="PerhtmlFormance" className="w3-col w3-third breakUp">
                                    <h4 className="w3-center w3-white">BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net Loans By Total Loans : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                  </div>
                                  <div data-toggle="tooltip" data-placement="top" title="change weightage" className="w3-col w3-third weights">
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net Loans By Total Loans : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return on Assets : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-row">
                                <hr />
                              </div>
                              <div className="w3-row AssetBandSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
                                            Asset Band wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
                                                Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4 className="w3-center w3-white">BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans per member Growth : </b>
                                      <span
                                        className="weight text-info"
                                      >
                                        0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net Loans By Total Loans : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '0%' }} />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net Loans By Total Loans : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return on Assets : </b>
                                      <span className="weight text-info">20%</span>
                                      <div className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <span className="ui-slider-handle ui-corner-all ui-state-default" style={{ left: '20%' }} />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-clear" />
                              <div className="w3-row">
                                <br />
                                <p>
                                  This ranks & scores are based on
                                  certain metrics , as shown in Break Up.
                                </p>
                                <p>
                                  User can change the assign weights and
                                  observe the change in Overall Ranking.
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Quarter wise comparison</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <table
                                style={{ width: '100%', 'text-align': 'center' }}
                                className="well nav nav-stacked table table-inverse text-center"
                              >
                                <thead>
                                  <tr className="w3-cyan">
                                    <th>Metric</th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodN">
                                    This Quarter
                                  </th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodO">
                                    Past Quarter
                                  </th>
                                    <th className="PeriodC">Change</th>
                                    <th>Trend</th>
                                    <th className="text-red">Delete</th>
                                  </tr>
                                </thead>
                                <tbody id="KEYPARAMS">
                                  <tr>
                                    <td colSpan="5">[object Object]</td>
                                  </tr>
                                  <tr />
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="sc2" className="tab-pane active">
                      <button style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }} className="btn-success btn-xs pull-right">
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-aqua">
                          <p style={{ 'font-size': '25px', margin: 0 }} className="lead"> Assets Scorecard</p>
                        </div>
                        <div className="panel-body">
                          <div className="w3-row w3-center">
                            <div className="w3-col w3-half MainSC">
                              <p className="lead">Name of CU :
                                <span className="text-info lead">{this.props.selectedCU.name}</span>
                              </p>
                              <p className="lead">State : <span className="text-info lead">CALIFORNIA</span>
                              </p>
                              <p className="lead">Members : <span className="text-info lead">XXXX</span>
                              </p>
                            </div>
                            <div className="w3-col w3-half">
                              <p className="lead">Assets : <span
                                className="text-info lead"
                              >$ XXX B</span>
                              </p>
                              <p className="lead">Asset Band : <span
                                className="text-info lead"
                              >$ XX - XX B</span>
                              </p>
                              <p className="lead">Loans : <span className="text-info lead">$ XXX B</span>
                              </p>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Key Metrics</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <div className="w3-row">
                                <p className="lead w3-card-8 w3-center w3-cyan">
                Scorecard Metrics</p>
                              </div>
                              <div className="w3-row w3-row-padding">
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Assets Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Loans Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Loans per member Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Net Loans by Total
                    loans </h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Return on Assets</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">ScoreCard &
              Ranking</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well w3-row-padding">
                              <div className="w3-row stateSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
                  State wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
                      Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4
                                      className="w3-center w3-white"
                                    >BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
                      Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
                  Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
              per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
          Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
        Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-row">
                                <hr />
                              </div>
                              <div className="w3-row AssetBandSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
        Asset Band wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
            Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4
                                      className="w3-center w3-white"
                                    >BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
            Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
        Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
        Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-clear" />
                              <div className="w3-row">
                                <br />
                                <p>This ranks & scores are based on certain metrics , as shown
        in Break Up.</p>
                                <p>User can change the assign weights and observe the change in
        Overall Ranking.</p>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Quarter wise
        comparison</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <table
                                style={{ width: '100%', 'text-align': 'center' }}
                                className="well nav nav-stacked table table-inverse text-center"
                              >
                                <thead>
                                  <tr className="w3-cyan">
                                    <th>Metric</th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodN">
              This Quarter
            </th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodO">
              Past Quarter
            </th>
                                    <th className="PeriodC">Change</th>
                                    <th>Trend</th>
                                    <th className="text-red">Delete</th>
                                  </tr>
                                </thead>
                                <tbody id="ASSETS">
                                  <tr>
                                    <td colSpan="5">[object Object]</td>
                                  </tr>
                                  <tr />
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="sc3" className="tab-pane">
                      <button style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }} className="btn-success btn-xs pull-right">
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-aqua">
                          <p style={{ 'font-size': '25px', margin: 0 }} className="lead"> Liabilities
            Scorecard</p>
                        </div>
                        <div className="panel-body">
                          <div className="w3-row w3-center">
                            <div className="w3-col w3-half MainSC">
                              <p className="lead">Name of CU : <span
                                className="text-info lead"
                              >{this.props.selectedCU.name}</span>
                              </p>
                              <p className="lead">State : <span className="text-info lead">CALIFORNIA</span>
                              </p>
                              <p className="lead">Members : <span className="text-info lead">XXXX</span>
                              </p>
                            </div>
                            <div className="w3-col w3-half">
                              <p className="lead">Assets : <span
                                className="text-info lead"
                              >$ XXX B</span>
                              </p>
                              <p className="lead">Asset Band : <span
                                className="text-info lead"
                              >$ XX - XX B</span>
                              </p>
                              <p className="lead">Loans : <span className="text-info lead">$ XXX B</span>
                              </p>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Key Metrics</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <div className="w3-row">
                                <p className="lead w3-card-8 w3-center w3-cyan">
                Scorecard Metrics</p>
                              </div>
                              <div className="w3-row w3-row-padding">
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Assets Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Loans Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Loans per member Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Net Loans by Total
                    loans </h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Return on Assets</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">ScoreCard & Ranking</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well w3-row-padding">
                              <div className="w3-row stateSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
                  State wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
                      Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4
                                      className="w3-center w3-white"
                                    >BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
                      Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
                  Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
              per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
          Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
        Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-row">
                                <hr />
                              </div>
                              <div className="w3-row AssetBandSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
        Asset Band wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
            Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4
                                      className="w3-center w3-white"
                                    >BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
            Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
        Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
        Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-clear" />
                              <div className="w3-row">
                                <br />
                                <p>
                                  This ranks & scores are based on
                                  certain metrics , as shown
                                  in Break Up.
                                </p>
                                <p>User can change the assign weights and observe the change in
        Overall Ranking.</p>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Quarter wise
        comparison</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <table
                                style={{ width: '100%', 'text-align': 'center' }}
                                className="well nav nav-stacked table table-inverse text-center"
                              >
                                <thead>
                                  <tr className="w3-cyan">
                                    <th>Metric</th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodN">
              This Quarter
            </th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodO">
              Past Quarter
            </th>
                                    <th className="PeriodC">Change</th>
                                    <th>Trend</th>
                                    <th className="text-red">Delete</th>
                                  </tr>
                                </thead>
                                <tbody id="LIABILITIES">
                                  <tr className="loader">
                                    <td colSpan="6">
                                      <i className="fa fa-spin fa-refresh" />
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="sc4" className="tab-pane">
                      <button
                        style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }}
                        className="btn-success btn-xs pull-right"
                      >
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-aqua">
                          <p style={{ 'font-size': '25px', margin: 0 }} className="lead"> Income & Expense
            Scorecard</p>
                        </div>
                        <div className="panel-body">
                          <div className="w3-row w3-center">
                            <div className="w3-col w3-half MainSC">
                              <p className="lead">Name of CU : <span
                                className="text-info lead"
                              >{this.props.selectedCU.name}</span>
                              </p>
                              <p className="lead">State : <span className="text-info lead">CALIFORNIA</span>
                              </p>
                              <p className="lead">Members : <span className="text-info lead">XXXX</span>
                              </p>
                            </div>
                            <div className="w3-col w3-half">
                              <p className="lead">Assets : <span
                                className="text-info lead"
                              >$ XXX B</span>
                              </p>
                              <p className="lead">Asset Band : <span
                                className="text-info lead"
                              >$ XX - XX B</span>
                              </p>
                              <p className="lead">Loans : <span className="text-info lead">$ XXX B</span>
                              </p>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Key Metrics</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <div className="w3-row">
                                <p className="lead w3-card-8 w3-center w3-cyan">
                Scorecard Metrics</p>
                              </div>
                              <div className="w3-row w3-row-padding">
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Assets Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Loans Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Loans per member Growth</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Net Loans by Total
                    loans </h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                                <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
                                  <div className="w3-container w3-padding-16">
                                    <h4
                                      className="w3-card-8 w3-white"
                                    >Return on Assets</h4>
                                    <div className="w3-row">
                                      <h3 className="metric">0.0%</h3>
                                    </div>
                                    <div className="w3-clear" />
                                    <p>State Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                    <br />
                                    <p>Asset Band Percentile</p>
                                    <input
                                      type="text"
                                      data-skin="tron"
                                      data-thickness="0.2"
                                      data-width="90"
                                      data-height="90"
                                      data-fgcolor="#3c8dbc"
                                      data-readonly="true"
                                      className="knob"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">ScoreCard &
              Ranking</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well w3-row-padding">
                              <div className="w3-row stateSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
                  State wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
                      Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4
                                      className="w3-center w3-white"
                                    >BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
                      Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
                  Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
              per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
          Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
        Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return on Assets : </b>
                                      <span className="weight text-info" >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-row">
                                <hr />
                              </div>
                              <div className="w3-row AssetBandSC w3-card-8">
                                <div className="w3-row">
                                  <p className="lead w3-card-8 w3-center w3-cyan">
        Asset Band wise</p>
                                </div>
                                <div className="w3-row">
                                  <div className="w3-col w3-third">
                                    <div className="m6 l3 w3-center knobSc">
                                      <h4 className="w3-white">
            Overall</h4>
                                      <input
                                        type="text"
                                        data-skin="tron"
                                        data-thickness="0.1"
                                        data-width="150"
                                        data-height="150"
                                        data-fgcolor="#3c8dbc"
                                        data-readonly="true"
                                        className="knob"
                                      />
                                      <p>Rank : 80/140</p>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="PerhtmlFormance"
                                    className="w3-col w3-third breakUp"
                                  >
                                    <h4
                                      className="w3-center w3-white"
                                    >BreakUp</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
            Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
        Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans per member Growth : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span className="weight text-info">0%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content ui-slider-disabled ui-state-disabled"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '0%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="change weightage"
                                    className="w3-col w3-third weights"
                                  >
                                    <h4 className="w3-center w3-white">Weights</h4>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Assets
        Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Loans
      per member Growth : </b>
                                      <span className="weight text-info">20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Net
      Loans By Total Loans : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                    <div className="w3-row">
                                      <br />
                                    </div>
                                    <div className="sliderBox h4 pull-left">
                                      <b className="text-info">Return
      on Assets : </b>
                                      <span
                                        className="weight text-info"
                                      >20%</span>
                                      <div
                                        className="slider w3-teal true ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                      >
                                        <span
                                          className="ui-slider-handle ui-corner-all ui-state-default"
                                          style={{ left: '20%' }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="w3-clear" />
                              <div className="w3-row">
                                <br />
                                <p>
                                  This ranks &
                                  scores are based on certain metrics,
                                  as shown in Break Up.
                                </p>
                                <p>
                                  User can change the assign weights and
                                  observe the change in Overall Ranking.
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="box box-info">
                            <div className="box-header with-border">
                              <h3 className="box-title">Quarter wise comparison</h3>
                              <div className="box-tools pull-right">
                                <button
                                  type="button"
                                  data-widget="collapse"
                                  className="btn btn-box-tool"
                                >
                                  <i className="fa fa-minus" />
                                </button>
                              </div>
                            </div>
                            <div style={{ display: 'block' }} className="box-body well">
                              <table style={{ width: '100%', 'text-align': 'center' }} className="well nav nav-stacked table table-inverse text-center">
                                <thead>
                                  <tr className="w3-cyan">
                                    <th>Metric</th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodN">
                                      This Quarter
                                    </th>
                                    <th data-toggle="modal" data-target="#modal" className="PeriodO">
                                      Past Quarter
                                    </th>
                                    <th className="PeriodC">Change</th>
                                    <th>Trend</th>
                                    <th className="text-red">Delete</th>
                                  </tr>
                                </thead>
                                <tbody id="IncomeExpense">
                                  <tr className="loader">
                                    <td colSpan="6">
                                      <i className="fa fa-spin fa-refresh" />
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="sc5" className="tab-pane">
                      <button style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }} className="btn-success btn-xs pull-right">
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-aqua">
                          <p style={{ 'font-size': '18px', margin: '0' }} className="lead"> PEARLS* Scorecard</p>
                        </div>
                        <div className="panel-body text-center">
                          <br />
                          <h4>Please upgrade your account to DaExpert or SuperUser</h4>
                          <Link to="http://localhost:8080/pricing" className="w3-btn w3-teal">Upgrade Now</Link>
                        </div>
                      </div>
                    </div>
                    <div id="sc6" className="tab-pane">
                      <button
                        style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }}
                        className="btn-success btn-xs pull-right"
                      >
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-aqua">
                          <p style={{ 'font-size': '18px', margin: '0' }} className="lead"> CAMELS* Scorecard</p>
                        </div>
                        <div className="panel-body text-center">
                          <br />
                          <h4>Please upgrade your account to DaExpert
          or SuperUser</h4>
                          <Link to="http://localhost:8080/pricing" className="w3-btn w3-teal">Upgrade
          Now</Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="tabs-2" className="tab-pane">
                <div className="nav-tabs-custom bg-gray">
                  <ul className="nav nav-tabs">
                    <li className="active">
                      <Link to="#it2" id="tabIT2" data-toggle="tab">Business Continuity Planning
            (BCP)</Link>
                    </li>
                    <li>
                      <Link to="#it3" id="tabIT3" data-toggle="tab">Total Cost of Ownership (TCO)</Link>
                    </li>
                    <li>
                      <Link to="#it4" id="tabIT4" data-toggle="tab">Disaster Recovery (DR)</Link>
                    </li>
                  </ul>
                  <div className="tab-content bg-gray">
                    <div id="it2" className="tab-pane active">
                      <button
                        style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }}
                        className="btn-success btn-xs pull-right"
                      >
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-yellow">
                          <p style={{ 'font-size': '18px', margin: '0' }} className="lead"> Business Continuity
                  Practises (BCP) Scorecard</p>
                        </div>
                        <div className="panel-body text-center">
                          <br />
                          <h4>Please upgrade your account to ITExpert
                or SuperUser</h4>
                          <Link to="http://localhost:8080/pricing" className="w3-btn w3-teal">Upgrade
                Now</Link>
                        </div>
                      </div>
                    </div>
                    <div id="it3" className="tab-pane">
                      <button
                        style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }}
                        className="btn-success btn-xs pull-right"
                      >
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-yellow">
                          <p style={{ 'font-size': '18px', margin: '0' }} className="lead"> Total Cost of Ownership
                  (TCO) Scorecard</p>
                        </div>
                        <div className="panel-body text-center">
                          <br />
                          <h4>Please upgrade your account to ITExpert
                or SuperUser</h4>
                          <Link to="http://localhost:8080/pricing" className="w3-btn w3-teal">Upgrade
                Now</Link>
                        </div>
                      </div>
                    </div>
                    <div id="it4" className="tab-pane">
                      <button style={{ 'margin-top': '-6.5%', 'margin-right': '1%' }} className="btn-success btn-xs pull-right">
                        <i className="fa fa-print fa-lg" />
                        <span>Print PDF</span>
                      </button>
                      <div className="panel panel-primary">
                        <div className="panel-heading text-center bg-yellow">
                          <p style={{ 'font-size': '18px', margin: '0' }} className="lead"> Disaster Recovery (DR) Scorecard</p>
                        </div>
                        <div className="panel-body text-center">
                          <br />
                          <h4>Please upgrade your account to ITExpert
                or SuperUser</h4>
                          <Link to="http://localhost:8080/pricing" className="w3-btn w3-teal">Upgrade
                Now</Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <p />
          <div id="modal" role="dialog" className="modal fade">
            <div className="modal-dialog">
              <div className="modal-content w3-htmlForm">
                <div className="modal-header">
                  <button type="button" data-dismiss="modal" className="close">×</button>
                  <h4 className="modal-title">Customize your reports ; Choose Different Quarters</h4>
                </div>
                <div className="modal-body">
                  <input type="text" name="Qscorecard" className="Qscorecard hidden" />
                  <label htmlFor="Qselect" className="control-label">This Quarter</label>
                  <br />
                  <select name="Qselect1" className="text-uppercase Qselect">
                    <option value="">Select Quarter</option>
                  </select>
                  <hr />
                  <label htmlFor="Qselect" className="control-label">Past Quarter</label>
                  <br />
                  <select name="Qselect2" className="text-uppercase Qselect">
                    <option value="">Select Quarter</option>
                  </select>
                  <br />
                  <hr />
                  <br />
                  <p className="text-warning">This Quarter should be later than Past Quarter</p>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" data-dismiss="modal" className="btn btn-default">Submit
          </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    culist: state.cu.culist,
    errorMessage: state.cu.error,
    selectedCU: state.cu.selectedCU,
    assets: state.cu.assets,
    metrics: state.cu.metrics,
    firstQtr: state.cu.firstQtr,
    secondQtr: state.cu.secondQtr,
    firstQtrList: state.cu.firstQtrList,
    secondQtrList: state.cu.secondQtrList,
  };
}

const mapDispatchToProps = dispatch => ({
  selectedItem: chosenRequest => dispatch({
    type: SELECTED_CU,
    payload: chosenRequest,
  }),
  selectFirstQtr: (event, index, value) => dispatch({
    type: FIRSTQTR,
    payload: value,
  }),
  selectSecondQtr: (event, index, value) => dispatch({
    type: SECONDQTR,
    payload: value,
  }),
  renderFirstQtrList: list => dispatch({
    type: `${FIRSTQTR}${LIST}`,
    payload: list,
  }),
  renderSecondQtrList: list => dispatch({
    type: `${SECONDQTR}${LIST}`,
    payload: list,
  }),
  renderReport: (selectedCU) => {
    dispatch(renderDashboard(selectedCU.cuNumber));
  },
  fetchCUList: () => dispatch(fetchCUList()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Main);

