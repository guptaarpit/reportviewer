/* eslint-disable react/prop-types */
/**
 * Created by arpit on 7/19/2017.
 */
import React from 'react';
import numeral from 'numeral';
import { SelectField } from 'material-ui';
import BarChart from './barChart';

const Widgets = (props) => {
  const { barData,
    itemData,
    metrics,
    parentProps,
    /*renderFirstQtrMenu,
    renderSecondQtrMenu,*/
  } = props;
  console.log(props);
  const firstQtrValue = parentProps.firstQtr ? parentProps.firstQtr : itemData[0].Quarter;
  const secondQtrValue = parentProps.secondQtr ? parentProps.secondQtr : itemData[itemData.length - 1].Quarter;
  const firstMetric = numeral(itemData[0][metrics.Metric]).value();
  const secondMetric = numeral(itemData[itemData.length - 1][metrics.Metric]).value();
  let profitLossIcon = '';
  if (firstMetric > secondMetric) {
    profitLossIcon = <i className="fa fa-chevron-up" style={{ color: 'green' }} />;
  } else if (firstMetric < secondMetric) {
    profitLossIcon = <i className="fa fa-chevron-down" style={{ color: 'red' }} />;
  }

  const profitLossValue = numeral(((firstMetric - secondMetric) * 100) / firstMetric).format('0.00');

  return (
    <div className="w3-col m6 l4 w3-card-8 w3-center keyParam">
      <div className="w3-container w3-padding-16">
        <h4 className="w3-card-8 w3-white">{metrics.Caption}</h4>
        <div className="w3-row">
          <h3 className="metric">{profitLossValue}% {profitLossIcon}</h3>
        </div>
        <div className="w3-clear" />
        <div style={{ display: 'inline', width: '90px', height: '90px' }} >
          <BarChart data={barData.data} options={barData.options} />
        </div>
        <br />
        {/*<SelectField value={parentProps.firstQtr} onChange={renderSecondQtrMenu}>
          {parentProps.firstQtrList}
        </SelectField>*/}
        <p>{firstQtrValue}</p>
        <p>{itemData[0][metrics.Metric]}</p>
        <br />
       {/* <SelectField value={parentProps.secondQtr} onChange={renderFirstQtrMenu}>
          {parentProps.secondQtrList}
        </SelectField>*/}
        <p>{secondQtrValue}</p>
        <p>{itemData[itemData.length - 1][metrics.Metric]}</p>
      </div>
    </div>
  );
};

export default Widgets;
