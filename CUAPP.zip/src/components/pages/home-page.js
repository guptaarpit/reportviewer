import React, { PureComponent } from 'react';

class HomePage extends PureComponent {
  render() {
    return (
      <div>Hello world! This is the home page route.</div>
    );
  }
}

export default HomePage;
