/**
 * Created by arpit on 7/18/2017.
 */
import { FETCH_ASSETS, FETCH_CULIST, FETCH_LIABILITIES, CU_ERRORS, FULFILLED, SELECTED_CU, FETCH_METRICS, FIRSTQTR, SECONDQTR, LIST } from '../actions/types';

const INITIAL_STATE = {
  assets: [],
  culist: [],
  liabilities: [],
  message: '',
  error: '',
  selectedCU: '',
  metrics: [],
  firstQtr: '',
  secondQtr: '',
  firstQtrList: '',
  secondQtrList: '',
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case `${FETCH_ASSETS}${FULFILLED}`:
      return {
        ...state, assets: action.payload,
      };
    case `${FETCH_LIABILITIES}${FULFILLED}`:
      return {
        ...state, liabilities: action.payload,
      };
    case `${FETCH_CULIST}${FULFILLED}`:
      return {
        ...state, culist: action.payload,
      };
    case `${CU_ERRORS}${FULFILLED}`:
      return {
        ...state, error: action.payload,
      };
    case `${SELECTED_CU}`:
      return {
        ...state, selectedCU: action.payload,
      };
    case `${FETCH_METRICS}${FULFILLED}`:
      return {
        ...state, metrics: action.payload,
      };
    case `${FIRSTQTR}${LIST}`:
      return {
        ...state, firstQtrList: action.payload,
      };
    case `${SECONDQTR}${LIST}`:
      return {
        ...state, secondQtrList: action.payload,
      };
    case `${FIRSTQTR}`:
      return {
        ...state, firstQtr: action.payload,
      };
    case `${SECONDQTR}`:
      return {
        ...state, secondQtr: action.payload,
      };
    default:
      return state;
  }
}
